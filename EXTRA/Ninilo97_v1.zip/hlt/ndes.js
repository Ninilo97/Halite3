function calNdes(game){
  const { gameMap, me } = game;
  gameMap.get(me.shipyard).expand=4;
  const ndes=[];
  ndes[0] = Object.assign({},gameMap.get(me.shipyard));
  var i=0,x=0;
  for(var y=0;y<3;y++){
    switch (ndes[x].expand) {
      case 0:
      x++;
      i++;
      ndes[i] = Object.assign({},ndes[x]);
      ndes[i].position=ndes[x].position.directionalOffset(Direction.getAllCardinals()[0]);
      ndes[i].expand=0;
      break;
      case 1:
      x++;
      i++;
      ndes[i] = Object.assign({},ndes[x]);
      ndes[i].position=ndes[x].position.directionalOffset(Direction.getAllCardinals()[1]);
      ndes[i].expand=1;
      break;
      case 2:
      x++;
      i++;
      ndes[i] = Object.assign({},ndes[x]);
      ndes[i].position=ndes[0].position.directionalOffset(Direction.getAllCardinals()[0]);
      ndes[i].expand=0;
      i++;
      ndes[i] = Object.assign({},ndes[x]);
      ndes[i].position=ndes[0].position.directionalOffset(Direction.getAllCardinals()[1]);
      ndes[i].expand=1;
      i++;
      ndes[i] = Object.assign({},ndes[x]);
      ndes[i].position=ndes[0].position.directionalOffset(Direction.getAllCardinals()[2]);
      ndes[i].expand=2;
      break;
      case 3:
      x++;
      i++;
      ndes[i] = Object.assign({},ndes[x]);
      ndes[i].position=ndes[0].position.directionalOffset(Direction.getAllCardinals()[0]);
      ndes[i].expand=0;
      i++;
      ndes[i] = Object.assign({},ndes[x]);
      ndes[i].position=ndes[0].position.directionalOffset(Direction.getAllCardinals()[1]);
      ndes[i].expand=1;
      i++;
      ndes[i] = Object.assign({},ndes[x]);
      ndes[i].position=ndes[0].position.directionalOffset(Direction.getAllCardinals()[3]);
      ndes[i].expand=3;
      break;
      case 4:
      ndes[1] = Object.assign({},ndes[0]);
      ndes[1].position=ndes[0].position.directionalOffset(Direction.getAllCardinals()[0]);
      ndes[1].expand=0;
      ndes[2] = Object.assign({},ndes[0]);
      ndes[2].position=ndes[0].position.directionalOffset(Direction.getAllCardinals()[1]);
      ndes[2].expand=1;
      ndes[3] = Object.assign({},ndes[0]);
      ndes[3].position=ndes[0].position.directionalOffset(Direction.getAllCardinals()[2]);
      ndes[3].expand=2;
      ndes[4] = Object.assign({},ndes[0]);
      ndes[4].position=ndes[0].position.directionalOffset(Direction.getAllCardinals()[3]);
      ndes[4].expand=3;
      i=4;
    }
  }
  ndes.splice(0,1);
}
