const hlt = require('./hlt');
const { Direction } = require('./hlt/positionals');
const logging = require('./hlt/logging');

const game = new hlt.Game();

function createArray(len, itm) {
  var arr1 = [itm],
  arr2 = [];
  while (len > 0) {
    if (len & 1) arr2 = arr2.concat(arr1);
    arr1 = arr1.concat(arr1);
    len >>>= 1;
  }
  return arr2;
}

game.initialize().then(async () => {

  const { gameMap, me } = game;
  // At this point "game" variable is populated with initial map data.
  // This is a good place to do computationally expensive start-up pre-processing.
  // As soon as you call "ready" function below, the 2 second per turn timer will start.
  await game.ready('4');

  while (true) {
    await game.updateFrame();

    const commandQueue = [];
    const shipAss=[];

    if (me.haliteAmount >= hlt.constants.SHIP_COST && !gameMap.get(me.shipyard).isOccupied && game.turnNumber < 250) {
      commandQueue.push(me.shipyard.spawn());
    }
    for (const ship of me.getShips()) {
      if(ship.haliteAmount>0.9*hlt.constants.MAX_HALITE){
        const destination = me.shipyard.position;
        const safeMove = gameMap.naiveNavigate(ship, destination);
        commandQueue.push(ship.move(safeMove));

      }
      else if(gameMap.get(ship.position).haliteAmount < 30){
        mxN=[];
        for(i=0;i<4;i++){
          mxN.push(gameMap.get(ship.position.directionalOffset(Direction.getAllCardinals()[i])));
        }
        const destination = mxN.filter(function(o) { return o.haliteAmount === Math.max.apply(Math, mxN.map(function(o) { return o.haliteAmount; }))});
        const safeMove = gameMap.naiveNavigate(ship, destination[0].position);
        commandQueue.push(ship.move(safeMove));
      }
      logging.debug("\n");
    }
    await game.endTurn(commandQueue);
  }
});
